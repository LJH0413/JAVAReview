package Test.thankGivigWork;

public class Student {
	
	private int score;
	
	int number;

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	

	
	
}
